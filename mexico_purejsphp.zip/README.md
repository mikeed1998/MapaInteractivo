# mapa-mexico-html5
Mapa Interactivo para la selección de un estado de la república Mexicana solo HTML5 y JavaScript
